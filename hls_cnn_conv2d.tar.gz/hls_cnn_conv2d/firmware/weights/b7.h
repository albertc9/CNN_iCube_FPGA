//Numpy array shape [1]
//Min 0.078648604453
//Max 0.078648604453
//Number of zeros 0

#ifndef B7_H_
#define B7_H_

#ifndef __SYNTHESIS__
dense_4_bias_t b7[1];
#else
dense_4_bias_t b7[1] = {0.0786486045};
#endif

#endif
