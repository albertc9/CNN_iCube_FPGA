//Numpy array shape [10]
//Min -0.032031074166
//Max 0.118700459599
//Number of zeros 0

#ifndef B4_H_
#define B4_H_

#ifndef __SYNTHESIS__
conv2d_1_1_bias_t b4[10];
#else
conv2d_1_1_bias_t b4[10] = {-0.0278398041, -0.0179336853, 0.0263150241, -0.0094271740, -0.0180941876, -0.0207262840, -0.0173174720, -0.0237524509, -0.0320310742, 0.1187004596};
#endif

#endif
